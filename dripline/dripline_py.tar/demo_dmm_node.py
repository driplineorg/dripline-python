#!/usr/bin/env python
from connection import Connection
from agilent34461a import VoltageInput

if __name__ == '__main__':
	main()

def main():
	# first start a connection to dripline
	drip_conn = Connection('myrna.phys.washington.edu')

	# now register the DMM voltage input as a channel called 'voltage'
	dmm = VoltageInput('dcv')
	drip_conn.bind(dmm)

	# now start the connection's event loop
	drip_conn.start()