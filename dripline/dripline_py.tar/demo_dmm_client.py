#!/usr/bin/env python
from connection import Connection
from message import RequestMessage
import constants as dc

if __name__ == '__main__':
	conn = Connection('myrna.phys.washington.edu')
	m = RequestMessage(msgtype=dc.T_REQUEST, msgop=dc.OP_SENSOR_GET, target='dcv')
	msg = Message.to_msgpack(m)

	result = conn.send_request('dcv',msg)
	print '{}'.format(result)