from factory import constructor_registry as cr

class Node(object):
	def __init__(self, configuration):
		self.conf = configuration
		self.providers = {}
		self._build_object_graph()

	def nodename(self):
		return self.conf.nodename

	def _build_object_graph(self):
		if self.conf.instrument_count() > 0:
			for name, items in self.conf.instruments.iteritems():
				instr_model = items['model']
				constructor = cr[instr_model]

				obj = constructor(name, items)
				
				for sensor in items['sensors']:
					handler = sensor.pop('handler')
					name = sensor.pop('name')
					s = cr[handler](name, **sensor)
					obj.add_endpoint(s)

				self.add_provider(obj)

	def provider_list(self):
		return self.providers.keys()

	def add_provider(self, provider):
		self.providers[provider.name] = provider

	def provider_endpoints(self, provider):
		return self.providers[provider].list_endpoints()

	def locate_provider(self, endpoint):
		for p, data in self.providers.iteritems():
			if endpoint in data.list_endpoints():
				return data
		return None